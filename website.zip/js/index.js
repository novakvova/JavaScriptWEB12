// let ask; //зберігає ім'я користувача
// ask = prompt("Як вас звати?");
// document.write("<h2>Привіт "+ ask+"!</h2>");

///----- Калькулятор ------
// let a, b, result;
// a=prompt("Вкажіть значення а");
// console.log("a = ", typeof(a));
// b=prompt("Вкажіть значення b");
// console.log("b = ", typeof(b));
// result = Number(a)+Number(b); // -, *, /, %
// //document.write("Результат а+b = "+ result);
// document.write(`Результат а+b = ${result}`);

//--------Буль тип bool(boolean) true, false---------
// let isTrue;
// isTrue = prompt("Ти цього хочеш?");
// document.write("Ви цього хочете: "+ isTrue+"  --- ");
// //document.write(Boolean(isTrue));
// document.write(Boolean(Number(isTrue)));

//-----------Операція %-------------

// let a=4%3; //
// //document.write("4%3 = ", a);
// a=7%3; //
// //document.write("7%3 = ", a);  
// a=18%20; //
// document.write("18%20 = ", a);  
//document.write("2**8 = ", 2**8); 

//console.log(svitlana);
//alert(ivan);
//document.write("<h2>Привіт JS</h2");
/* alert("Привіт!");
 alert("Пака!"); */